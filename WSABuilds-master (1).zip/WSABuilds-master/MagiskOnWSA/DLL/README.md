# WSAPatch

<https://github.com/cinit/WSAPatch/releases>
