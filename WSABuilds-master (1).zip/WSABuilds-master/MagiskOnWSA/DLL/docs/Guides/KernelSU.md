# Install KernelSU Manager

## Text Guide

1. [Connect to WSA with ADB](ADB-Sideloading.md#setting-up-adb-to-work-with-wsa)
2. Run the following command:
   ```
   adb shell ksuinstall
   ```
   
If the installation completes successfully, the KernelSU Manager will launching.

<!--
## Video Guide
-->
