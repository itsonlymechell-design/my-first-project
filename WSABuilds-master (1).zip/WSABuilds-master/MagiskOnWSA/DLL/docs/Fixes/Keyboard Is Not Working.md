## Issue: Keyboard Does Not Work

### Preface: 
##### This issue will prevent you from using your keyboard on WSA


## Solution:

#### 1. ***Open Run by pressing the Windows Key and R***

<br>

#### 2. ***Type in services.msc in the box and then select OK***

<br>

#### 3. ***Search for Touch Keyboard and Handwriting Panel***

<br>

#### 4. ***Enable it by switching startup type to automatic***

<br>

#### 5. ***Click apply*** 

<br>

#### 6. ***Restart your computer.*** 

