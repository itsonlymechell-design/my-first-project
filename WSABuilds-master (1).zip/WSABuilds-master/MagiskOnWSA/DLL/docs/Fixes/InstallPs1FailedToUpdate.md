## Issues: Install.ps1 Failed To Update

&nbsp;

<img src="https://github.com/MustardChef/WSABuilds/assets/68516357/7dff07f2-fde7-40b8-946c-d63ea18b2f99"/>

## Solution: 

1. Run Powershell with this command:
```powershell
PowerShell.exe -ExecutionPolicy Bypass -File .\Install.ps1
```
&nbsp;
