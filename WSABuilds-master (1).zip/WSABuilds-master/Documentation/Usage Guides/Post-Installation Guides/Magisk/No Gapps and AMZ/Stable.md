<p align="center"><picture><img src="https://github.com/MustardChef/WSABuilds/assets/68516357/1e0497d6-356d-49b4-9e73-0d4a2a9b570e" width="55%" height="55%"/></p>


<h1><p align="center">You Have Successfully Installed Windows Subsystem For Android with Magisk Stable and Amazon Appstore!</p></h1>
<h2><p align="center">Stability: ⚠️ Unstable</p></h2> <h2><p align="center"><i><b>ISSUE: Module Disappears after install and reboot (https://github.com/MustardChef/WSABuilds/issues/154) on some PCs<i><b><br /><br /><a href="https://github.com/MustardChef/WSABuilds/issues/154#issuecomment-1729105000"><img alt="Static Badge" src="https://img.shields.io/badge/temporary%20Workaround-0349aa?style=for-the-badge&logo=github" style="width: 320px;"/></a></p></h2>
<br />
<br />

 <h1><p align="center">Having any issues? &nbsp; &nbsp; &nbsp;<a href="https://github.com/MustardChef/WSABuilds/blob/master/Documentation/Fix%20Guides/Troubleshooting.md"><img src="https://img.shields.io/badge/Troubleshoot-1c86af?style=for-the-badge&logoColor=white&logo=github" width="20%" height="20%"/></a></p><h3> Click on the "Troubleshoot" button above or join the WSA Community Discord server via the invite below to recieve advice and support!</h3><h1><p align="center"><a href="https://discord.gg/2thee7zzHZ"><img src="https://invidget.switchblade.xyz/2thee7zzHZ" style="width: 420px;"/></a></p></h1>
