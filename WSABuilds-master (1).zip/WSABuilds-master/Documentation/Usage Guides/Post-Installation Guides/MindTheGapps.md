<p align="center"><picture><img src="https://github.com/MustardChef/WSABuilds/assets/68516357/acaf6ba0-e3a1-4e89-8199-dce2d05db64d" width="55%" height="55%"/></p>


<h1><p align="center">You Have Successfully Installed Windows Subsystem For Android with MindTheGapps and Amazon Appstore Removed!</p></h1>
<h2><p align="center">Stability: ✅Stable &nbsp; &nbsp; &nbsp;→ &nbsp; &nbsp; &nbsp; <i><b>No issues reported<i><b></p></h2>

<br />
<br />


# Having any issues?

### Join the WSA Community Discord server via the invite below to recieve advice and support!
[<img align="left" src="https://invidget.switchblade.xyz/2thee7zzHZ" style="width: 400px;"/>](https://discord.gg/2thee7zzHZ)
