<p align="center"><picture><img src="https://github.com/MustardChef/WSABuilds/assets/68516357/cfa27ee2-fad0-4cea-9b2e-bc6008cd6fff" width="55%" height="55%"/></p>


<h1><p align="center">You Have Successfully Installed Windows Subsystem For Android with Magisk Delta and MindTheGapps (and Amazon Appstore removed)!</p></h1>
<h2><p align="center">Stability: ⚠️ Unstable</p></h2> <h2><p align="center"><i><b>ISSUE: Module Disappears after install and reboot (https://github.com/MustardChef/WSABuilds/issues/154) on some PCs<i><b><br /><br /><a href="https://github.com/MustardChef/WSABuilds/issues/154#issuecomment-1729105000"><img alt="Static Badge" src="https://img.shields.io/badge/temporary%20Workaround-0349aa?style=for-the-badge&logo=github" style="width: 320px;"/></a></p></h2>

<br />
<br />


# Having any issues?

### Join the WSA Community Discord server via the invite below to recieve advice and support!
[<img align="left" src="https://invidget.switchblade.xyz/2thee7zzHZ" style="width: 400px;"/>](https://discord.gg/2thee7zzHZ)
