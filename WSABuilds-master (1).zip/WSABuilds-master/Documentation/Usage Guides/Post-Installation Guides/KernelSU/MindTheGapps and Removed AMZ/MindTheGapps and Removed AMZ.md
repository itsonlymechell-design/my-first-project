<p align="center"><picture><img src="https://github.com/MustardChef/WSABuilds/assets/68516357/0464460b-c6c5-4ce3-b765-f9012ebaad1a" width="55%" height="55%"/></p>



<h1><p align="center">You Have Successfully Installed Windows Subsystem For Android with KernelSU, Google Apps (MindTheGapps) and Removed Amazon!</p></h1>
<h2><p align="center">Stability: ✅Stable &nbsp; &nbsp; &nbsp;→ &nbsp; &nbsp; &nbsp; <i><b>No issues reported<i><b></p></h2>

<br />

## Next Steps:

<br />

### 1. Download the KernelSU Manager .apk

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [<img src="https://user-images.githubusercontent.com/68516357/226141505-c93328f9-d6ae-4838-b080-85b073bfa1e0.png" style="width: 200px;"/>](https://github.com/tiann/KernelSU/releases/download/v0.6.8/KernelSU_v0.6.8_11238-release.apk)

### 2. Sideload the KernelSU Manager .apk into WSA
  
<br />

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [<img src="https://img.shields.io/badge/-How%20to%20Sideload%20apps-474154?style=for-the-badge&logoColor=white&logo=github" style="width: 300px;"/>](https://github.com/MustardChef/WSABuilds/blob/master/Documentation/Usage%20Guides/Sideloading%20Guides/Sideloading.md)

<br />

---

<br />

 <h1><p align="center">Having any issues? &nbsp; &nbsp; &nbsp;<a href="https://github.com/MustardChef/WSABuilds/blob/master/Documentation/Fix%20Guides/Troubleshooting.md"><img src="https://img.shields.io/badge/Troubleshoot-1c86af?style=for-the-badge&logoColor=white&logo=github" width="20%" height="20%"/></a></p><h3> Click on the "Troubleshoot" button above or join the WSA Community Discord server via the invite below to recieve advice and support!</h3><h1><p align="center"><a href="https://discord.gg/2thee7zzHZ"><img src="https://invidget.switchblade.xyz/2thee7zzHZ" style="width: 420px;"/></a></p></h1>

