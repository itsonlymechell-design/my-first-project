#  Old WSA Builds

<img src="https://upload.wikimedia.org/wikipedia/commons/e/e6/Windows_11_logo.svg" style="width: 200px;"/>

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202311.40000.4.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2311.40000.4.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202311.40000.4.0-Download%20arm64-800040?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2311.40000.4.0_arm64)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202310.40000.2.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2310.40000.2.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202310.40000.2.0-Download%20arm64-800040?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2310.40000.2.0_arm64)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202309.40000.2.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2309.40000.2.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202309.40000.2.0-Download%20arm64-800040?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2309.40000.2.0_arm64)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202308.40000.3.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2308.40000.3.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202308.40000.3.0-Download%20arm64-800040?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2308.40000.3.0_arm64)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202308.40000.1.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2308.40000.1.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202308.40000.1.0-Download%20arm64-800040?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2308.40000.1.0_arm64)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202307.40000.6.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2307.40000.6.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202307.40000.6.0-Download%20arm64-800040?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2307.40000.6.0_arm64)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202307.40000.5.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2307.40000.5.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202307.40000.5.0-Download%20arm64-800040?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2307.40000.5.0_arm64)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202307.40000.3.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2307.40000.3.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202307.40000.3.0-Download%20arm64-800040?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2307.40000.3.0_arm64)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202307.40000.2.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2307.40000.2.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202307.40000.2.0-Download%20arm64-800040?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2307.40000.2.0_arm64)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202306.40000.4.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2306.40000.4.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202306.40000.4.0-Download%20arm64-800040?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2306.40000.4.0_arm64)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202306.40000.3.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2306.40000.3.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202306.40000.3.0-Download%20arm64-800040?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2306.40000.3.0_arm64)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202306.40000.2.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2306.40000.2.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202306.40000.2.0-Download%20arm64-800040?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2306.40000.2.0_arm64)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202306.40000.1.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2306.40000.1.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202306.40000.1.0-Download%20arm64-800040?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2306.40000.1.0_arm64)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202305.40000.6.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2305.40000.6.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202305.40000.6.0-Download%20arm64-800040?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2305.40000.6.0_arm64)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202305.40000.5.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2305.40000.5.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202305.40000.5.0-Download%20arm64-800040?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2305.40000.5.0_arm64)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202305.40000.4.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2305.40000.4.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202305.40000.4.0-Download%20arm64-800040?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2305.40000.4.0_arm64)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202305.40000.3.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2305.40000.3.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202305.40000.3.0-Download%20arm64-800040?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2305.40000.3.0_arm64)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202305.40000.2.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2305.40000.2.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202305.40000.2.0-Download%20arm64-800040?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2305.40000.2.0_arm64)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202304.40000.10.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2304.40000.10.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202304.40000.10.0-Download%20arm64-800040?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2304.40000.10.0_arm64)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202304.40000.7.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2304.40000.7.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202304.40000.7.0-Download%20arm64-800040?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2304.40000.7.0_arm64)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202304.40000.6.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2304.40000.6.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202304.40000.6.0-Download%20arm64-800040?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2304.40000.6.0_arm64)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202304.40000.5.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2304.40000.5.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202304.40000.5.0-Download%20arm64-800040?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2304.40000.5.0_arm64)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202304.40000.4.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2304.40000.4.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202304.40000.4.0-Download%20arm64-800040?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2304.40000.4.0_arm64)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202303.40000.5.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2303.40000.5.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202303.40000.5.0-Download%20arm64-800040?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2303.40000.5.0_arm64)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202303.40000.4.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2303.40000.4.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202303.40000.4.0-Download%20arm64-800040?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2303.40000.4.0_arm64)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202303.40000.3.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2303.40000.3.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202303.40000.3.0-Download%20arm64-800040?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2303.40000.3.0_arm64)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202303.40000.2.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2303.40000.2.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202303.40000.2.0-Download%20arm64-800040?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2303.40000.2.0_arm64)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202302.40000.9.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2302.40000.9.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202302.40000.9.0-Download%20arm64-800040?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2302.40000.9.0_arm64)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202302.40000.8.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2302.40000.8.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202302.40000.8.0-Download%20arm64-800040?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2302.40000.8.0_arm64)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202302.40000.6.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2302.40000.6.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202302.40000.6.0-Download%20arm64-800040?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2302.40000.6.0_arm64)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202301.40000.7.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2301.40000.7.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202301.40000.7.0-Download%20arm64-800040?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2301.40000.7.0_arm64)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202301.40000.4.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2301.40000.4.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202301.40000.4.0-Download%20arm64-800040?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2301.40000.4.0_arm64)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202211.40000.11.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2211.40000.11.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202211.40000.10.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2211.40000.10.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202210.40000.7.0-Download%20x64-blueviolet?style=for-the-badge&logo=windows11)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_11_2210.40000.7.0)

&nbsp;

<img src="https://upload.wikimedia.org/wikipedia/commons/0/05/Windows_10_Logo.svg" style="width: 200px;"/>

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202311.40000.4.0-Download%20x64-9cf?style=for-the-badge&logo=windows)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_10_2311.40000.4.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202310.40000.2.0-Download%20x64%20-9cf?style=for-the-badge&logo=windows)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_10_2310.40000.2.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202309.40000.2.0-Download%20x64%20-9cf?style=for-the-badge&logo=windows)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_10_2309.40000.2.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202308.40000.3.0-Download%20x64%20-9cf?style=for-the-badge&logo=windows)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_10_2308.40000.3.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202308.40000.1.0-Download%20x64%20-9cf?style=for-the-badge&logo=windows)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_10_2308.40000.1.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202307.40000.6.0-Download%20x64%20-9cf?style=for-the-badge&logo=windows)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_10_2307.40000.6.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202307.40000.5.0-Download%20x64%20-9cf?style=for-the-badge&logo=windows)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_10_2307.40000.5.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202307.40000.3.0-Download%20x64%20-9cf?style=for-the-badge&logo=windows)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_10_2307.40000.3.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202307.40000.2.0-Download%20x64%20-9cf?style=for-the-badge&logo=windows)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_10_2307.40000.2.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202306.40000.4.0-Download%20x64%20-9cf?style=for-the-badge&logo=windows)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_10_2306.40000.4.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202306.40000.3.0-Download%20x64%20-9cf?style=for-the-badge&logo=windows)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_10_2306.40000.3.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202306.40000.2.0-Download%20x64%20-9cf?style=for-the-badge&logo=windows)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_10_2306.40000.2.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202306.40000.1.0-Download%20x64%20-9cf?style=for-the-badge&logo=windows)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_10_2306.40000.1.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202305.40000.6.0-Download%20x64%20-9cf?style=for-the-badge&logo=windows)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_10_2305.40000.6.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202305.40000.5.0-Download%20x64%20-9cf?style=for-the-badge&logo=windows)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_10_2305.40000.5.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202305.40000.4.0-Download%20x64%20-9cf?style=for-the-badge&logo=windows)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_10_2305.40000.4.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202305.40000.3.0-Download%20x64%20-9cf?style=for-the-badge&logo=windows)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_10_2305.40000.3.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202304.40000.10.0-Download%20x64%20-9cf?style=for-the-badge&logo=windows)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_10_2304.40000.10.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202303.40000.5.0-Download%20x64%20-9cf?style=for-the-badge&logo=windows)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_10_2303.40000.5.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202303.40000.4.0-Download%20x64%20-9cf?style=for-the-badge&logo=windows)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_10_2303.40000.4.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202303.40000.3.0-Download%20x64%20-9cf?style=for-the-badge&logo=windows)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_10_2303.40000.3.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202303.40000.2.0-Download%20x64%20-9cf?style=for-the-badge&logo=windows)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_10_2303.40000.2.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202302.40000.9.0-Download%20x64%20-9cf?style=for-the-badge&logo=windows)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_10_2302.40000.9.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202302.40000.8.0-Download%20x64%20-9cf?style=for-the-badge&logo=windows)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_10_2302.40000.8.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202302.40000.6.0-Download%20x64%20-9cf?style=for-the-badge&logo=windows)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_10_2302.40000.6.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202301.40000.7.0-Download%20x64%20-9cf?style=for-the-badge&logo=windows)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_10_2301.40000.7.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202301.40000.4.0-Download%20x64%20-9cf?style=for-the-badge&logo=windows)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_10_2301.40000.4.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202211.40000.11.0-Download%20x64%20-9cf?style=for-the-badge&logo=windows)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_10_2211.40000.11.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202211.40000.10.0-Download%20x64%20-9cf?style=for-the-badge&logo=windows)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_10_2211.40000.10.0)

[![](https://img.shields.io/badge/Windows%20Subsystem%20For%20Android%3A%202210.40000.7.0-Download%20x64-9cf?style=for-the-badge&logo=windows)](https://github.com/MustardChef/WSABuilds/releases/tag/Windows_10_2210.40000.7.0)

