# WSABuilds &nbsp; &nbsp; <img src="https://img.shields.io/github/downloads/MustardChef/WSABuilds/total?label=Total%20Downloads&style=for-the-badge"/> &nbsp; 
<br/>


## Issue: Keyboard Does Not Work

### Preface: 
##### This issue will prevent you from using your keyboard on WSA


## Solution:

#### 1. ***Open Run by pressing the Windows Key and R***

<br />

#### 2. ***Type in services.msc in the box and then select OK***

<br />

#### 3. ***Search for Touch Keyboard and Handwriting Panel***

<br />

#### 4. ***Enable it by switching startup type to automatic***

<br />

#### 5. ***Click apply*** 

<br />

#### 6. ***Restart your computer.*** 



<br />

---

## Have futher question or need help?

#### Join the Discord if you have any other questions or need help!

[<img src="https://invidget.switchblade.xyz/2thee7zzHZ" style="width: 400px;"/>](https://discord.gg/2thee7zzHZ)
