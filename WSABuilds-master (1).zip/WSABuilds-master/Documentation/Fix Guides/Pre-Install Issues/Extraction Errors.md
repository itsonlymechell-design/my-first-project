# WSABuilds &nbsp; &nbsp; <img src="https://img.shields.io/github/downloads/MustardChef/WSABuilds/total?label=Total%20Downloads&style=for-the-badge"/> &nbsp; 

## Error: Cannot Extract Files from the .7z archives for the WSA Builds

<br />

- ### *7-zip*
<img src="https://cdn.discordapp.com/attachments/1096705940285304902/1189194007562170410/image.png?ex=659d4639&is=658ad139&hm=d267becf2e01d6dd4530fd72877033088a534a4d27ddee3a2358d1111dcb8dba&" width="30%" height="30%"/>

- ### *WinRAR*
<img src="https://media.discordapp.net/attachments/1065761648293462106/1187845128006684743/image.png?ex=65985dfb&is=6585e8fb&hm=4320f661b9a02221abc492938186e5bca60d49bad20aaec39759f377c6efb791&=&format=webp&quality=lossless&width=1440&height=328" width="30%" height="30%"/>

- ### *Windows Archive Extractor* 
<img src="https://cdn.discordapp.com/attachments/1096705940285304902/1188930320473530478/image.png?ex=659c50a5&is=6589dba5&hm=4e2c2e1f49bcefd6c9ac44d15bc2714652df7e3e78d987a9fa66f407e79bff77&" width="30%" height="30%"/>

---

## Solution

</br>

### DO NOT USE THE BUILT IN WINDOWS ARCHIVE EXTRACTOR

</br>

### Ensure that WinRAR/ 7-Zip is up to date
###### or
### If you still encounter issues, reinstall WinRAR/ 7-Zip
