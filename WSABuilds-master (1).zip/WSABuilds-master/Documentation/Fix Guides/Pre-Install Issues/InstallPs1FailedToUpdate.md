# WSABuilds &nbsp; &nbsp; <img src="https://img.shields.io/github/downloads/MustardChef/WSABuilds/total?label=Total%20Downloads&style=for-the-badge"/> &nbsp; 

&nbsp;
&nbsp;

## Issues: Install.ps1 Failed To Update

&nbsp;
&nbsp;

<img src="https://github.com/MustardChef/WSABuilds/assets/68516357/7dff07f2-fde7-40b8-946c-d63ea18b2f99"/>

## Solution: 

&nbsp;

**1. Execute:**
```powershell
PowerShell.exe -ExecutionPolicy Bypass -File .\Install.ps1
```
&nbsp;

**Hope this works for you!**


<br />

---

## Have futher question or need help?

#### Join the Discord if you have any other questions or need help!

[<img src="https://invidget.switchblade.xyz/2thee7zzHZ" style="width: 400px;"/>](https://discord.gg/2thee7zzHZ)
